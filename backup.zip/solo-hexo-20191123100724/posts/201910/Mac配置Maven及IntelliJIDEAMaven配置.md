title: Mac配置Maven及IntelliJ IDEA Maven配置
date: '2019-10-17 11:25:25'
updated: '2019-10-17 11:25:25'
tags: [idea, java]
permalink: /articles/2019/10/17/1571282725800.html
---
# Mac配置Maven
### 1、下载完以后其实就是一个压缩包，解压即可，解压出来的文件如下图所示，图片里面画线的就是咱们下载的压缩包。

  
![null](https://upload-images.jianshu.io/upload_images/14020633-e4b1c0142e846208.png?imageMogr2/auto-orient/strip|imageView2/2/w/838/format/webp)


### 2、然后咱们去/usr/local目录下面(可以打开Finder command+shift+G)，把解压出来的文件拷贝到这个目录下面。


![null](https://upload-images.jianshu.io/upload_images/14020633-08d9069bd075fbca.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)


### 3、接下来就是要去配置环境变量，然后去看看 ~/ 目录下面有没有 .bash_profile文件

```shell
vi ~/.bash_profile

```
* 之后咱们配置一下环境变量，对应自己的版本号

```shell
export PATH=$PATH:/usr/local/apache-maven-3.3.9/bin

```

* ok，ESC一下 然后 ： wq保存一下，然后在终端让命令生效一下

```shell
source ~/.bash_profile

```

### 4、这样我们来测试一下环境变量是否已经配置完成。在终端输入一个 mvn -v。如果出现下图则配置成功，如果没有的话，可以去检查一下 路径是否正确，或者版本号名称之类的。

![image.png](https://img.hacpai.com/file/2019/10/image-477aacdf.png)


配置信息.png

## 5、Maven很像一个很大仓库，装了很多的jar包，我们需要的时候就去拿，这就涉及到一个“本地仓库”的问题，默认情况，会在/user/username/.m2下






# 配置IntelliJ IDEA

### 1. 打开IntelliJ IDEA->configure->preference->Build->Build Tools->Maven
 
![null](https://upload-images.jianshu.io/upload_images/14020633-b49a632eaf632156.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

IntelliJ IDEA2.png

### 2. 主要配置我上图圈的这三个内容，开始的时候IDEA会用自己的一个Maven，点击后面的按钮开始选择路径，这时候你发现你找不到usr了，你按一下**comman+shift+.**即可显示隐藏内容，或者直接手动输入 /usr/local/apache-maven3.3.9即可。

### 3. 在开始之前，将后面两个打钩，第二项内容这边选择setting.xml 即 选择你在上一个路径下面的/usr/local/apache-maven3.3.9/conf下面的settings文件
    
### 4. 第三个文件也就是本地仓库文件，在上一步配置Maven的时候我们已经在这个路径下面配置并且下载了一些中央库里面的包，所以选择该路径下面的repository即可
     
![image.png](https://img.hacpai.com/file/2019/10/image-d3caaf28.png)
配置后的图也可以不改idea原本的仓库位置