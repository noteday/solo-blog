title: Github API v3-OAuth遇到的错误
date: '2019-10-15 17:13:40'
updated: '2019-10-17 12:17:08'
tags: [GitHub]
permalink: /articles/2019/10/15/1571130820108.html
---
# Common errors for the authorization request 授权请求的常见错误
在为用户获取 OAuth 令牌的过程中，可能会出现一些问题。 在初始授权请求阶段，您可能会看到以下一些错误:*
### （1）### 暂停申请
如果您设置的 OAuth 应用程序被暂停(由于报告的滥用、垃圾邮件或者 API 的错误使用) ，GitHub 将重定向到注册的回调 URL，并使用以下参数来总结错误:
```
http://your-application.com/callback?error=application_suspended  
&error_description=Your+application+has+been+suspended.+Contact+support@github.com. &error_uri=https://developer.github.com/v3/oauth/%23application-suspended&state=xyz
```
方法：请与技术支持部门联系，解决暂停申请的问题。
### （2） 重定向 URI 不匹配
如果你提供的重定向 uri 与你在应用程序中注册的不匹配，GitHub 将重定向到注册的回调 URL，并使用以下参数总结错误:
```
http://your-application.com/callback?error=redirect_uri_mismatch
&error_description=The+redirect_uri+MUST+match+the+registered+callback+URL+for+this+application. &error_uri=https://developer.github.com/v3/oauth/%23redirect-uri-mismatch &state=xyz
```
方法：若要更正此错误，请提供与您注册的内容相匹配的重定向 uri，或者省略此参数以使用在应用程序中注册的默认参数。
### （3）Access denied 拒绝访问
如果用户拒绝访问你的应用程序，GItHub 将重定向到注册的回调 URL，并使用以下参数总结错误:
```
http://your-application.com/callback?error=access_denied
  &error_description=The+user+has+denied+your+application+access.
  &error_uri=https://developer.github.com/v3/oauth/%23access-denied
  &state=xyz
```
方法：这里没有什么可以做的，因为用户可以自由选择不使用您的应用程序。 通常情况下，用户会关闭窗口或者在浏览器中按回去，所以你很可能永远不会看到这个错误。

