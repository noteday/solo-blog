title: mysql常用的命令
date: '2019-09-19 22:43:42'
updated: '2019-09-19 22:43:42'
tags: [待分类]
permalink: /articles/2019/09/19/1568904222635.html
---
``seffsdfwerwr1.建立一个任何ip可以访问任何数据库的用户


