title: 通过日志恢复mysql中误操作丢失的数据
date: '2019-11-05 09:48:47'
updated: '2019-11-05 09:48:47'
tags: [mysql]
permalink: /articles/2019/11/05/1572918527845.html
---
# 1.先确认自己的数据库中是否开启了binlog
（1）登录自己的数据库
```
mysql -u user -p；
```
（2）检查自己的是否开启了binblog(ON为开启)
```
show variables like '%log_bin%';
```
![image.png](https://img.hacpai.com/file/2019/11/image-2b23106e.png)

（3）查看binlog存放日志文件的目录
```
show variables like '%datadir%';
```
![image.png](https://img.hacpai.com/file/2019/11/image-031e3d0e.png)

# 2.进入binlog文件目录，找出日志文件
![image.png](https://img.hacpai.com/file/2019/11/image-95582635.png)
**其中mysql-bin.000007和mysql-bin.000008就是日志文件**
# 3.进入到mysql具体的安装目录下的bin目录下，找到工具mysqlbinlog
![image.png](https://img.hacpai.com/file/2019/11/image-2d9e55fa.png)

# 4.通过mysqlbinlog工具命令查看数据库增删改查记录

查询2019-11-4 09:00:00到2019-11-5 20:00:00 数据库为 solo 的操作日志，输入如下命令将数据写入到一个备用的1.txt文件中,1.txt会保存在本目录下
```
./mysqlbinlog --no-defaults --database=solo --start-datetime="2019-11-4 09:00:00" --stop-datetime="2019-11-5 20:00:00" /www/server/data/mysql-bin.000008  > 1.txt
```
# 5.通过日志中误操作之前的sql语句恢复数据

![image.png](https://img.hacpai.com/file/2019/11/image-aa38860c.png)

