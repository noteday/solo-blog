title: idea的快捷键
date: '2019-10-20 21:39:17'
updated: '2019-10-20 21:39:17'
tags: [idea, java]
permalink: /articles/2019/10/20/1571578757864.html
---
### 1.打开配置文件
```
command+shift+alt+?  
```
![image.png](https://img.hacpai.com/file/2019/10/image-dc00e207.png)

