title: idea的快捷键
date: '2019-10-20 21:39:17'
updated: '2019-10-20 21:39:17'
tags: [idea, java]
permalink: /articles/2019/10/20/1571578757864.html
---
### 1.打开配置文件
```
command+shift+alt+?  
```
![image.png](https://img.hacpai.com/file/2019/10/image-dc00e207.png)
### 2.快捷显示类中实现的方法
```
command+F12
```
![image.png](https://img.hacpai.com/file/2019/10/image-63193567.png)
### 3.格式化
```
command + option + L
```
### 4.最近修改的文件列表
```
command+E
```
![image.png](https://img.hacpai.com/file/2019/10/image-f5da3167.png)
### 5.查找此方法的Usages
```
command+B
```
### 6.提取对象
```
command+alt+v
```